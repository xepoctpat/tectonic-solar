// ===== NOAA SPACE WEATHER DATA INTEGRATION =====
const NOAA_APIS = {
  solarWind: 'https://services.swpc.noaa.gov/json/rtsw/rtsw_mag_1m.json',
  kpIndex: 'https://services.swpc.noaa.gov/json/planetary_k_index_1m.json',
  xrayFlux: 'https://services.swpc.noaa.gov/json/goes/primary/xrays-7-day.json',
  protonFlux: 'https://services.swpc.noaa.gov/json/goes/primary/integral-protons-plot-6-hour.json'
};

const spaceWeatherCache = {
  solarWind: null,
  kpIndex: null,
  xrayFlux: null,
  lastUpdate: 0
};

const alertSettings = {
  earthquakeMagnitude: 6.0,
  kpThreshold: 6,
  solarFlareClass: 'M',
  enabled: true
};

let historicalStorms = [];
let historicalEarthquakes = [];

// ===== LEAFLET MAP IMPLEMENTATION =====
let map = null;
let earthquakeMarkers = [];
let tectonicOverlays = [];
let currentTileLayer = null;
let demoEarthquakes = [
  { mag: 6.2, lat: 38.0, lon: 140.0, place: 'Japan Region', depth: 45, time: new Date(Date.now() - 7200000).toLocaleString() },
  { mag: 5.8, lat: -15.0, lon: -173.0, place: 'Tonga', depth: 55, time: new Date(Date.now() - 18000000).toLocaleString() },
  { mag: 5.2, lat: -2.5, lon: 118.0, place: 'Indonesia', depth: 90, time: new Date(Date.now() - 28800000).toLocaleString() },
  { mag: 4.8, lat: 36.0, lon: -120.0, place: 'California', depth: 12, time: new Date(Date.now() - 3600000).toLocaleString() },
  { mag: 4.7, lat: 63.0, lon: -152.0, place: 'Alaska', depth: 22, time: new Date(Date.now() - 14400000).toLocaleString() }
];

const tileLayers = {
  standard: {
    url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    name: 'Standard'
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles © Esri',
    name: 'Satellite'
  },
  terrain: {
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attribution: '© <a href="https://opentopomap.org">OpenTopoMap</a> (CC-BY-SA)',
    name: 'Terrain'
  },
  dark: {
    url: 'https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png',
    attribution: '© <a href="https://carto.com/">CARTO</a>',
    name: 'Dark'
  }
};

function initializeMap() {
  map = L.map('map-display', {
    center: [20, 0],
    zoom: 2,
    zoomControl: false,
    minZoom: 2,
    maxZoom: 18
  });
  currentTileLayer = L.tileLayer(tileLayers.satellite.url, {
    attribution: tileLayers.satellite.attribution,
    maxZoom: 18
  }).addTo(map);
  L.control.zoom({ position: 'bottomright' }).addTo(map);
  L.control.scale({ position: 'bottomleft' }).addTo(map);
}

function switchMapType(type) {
  if (currentTileLayer) map.removeLayer(currentTileLayer);
  const layer = tileLayers[type];
  currentTileLayer = L.tileLayer(layer.url, {
    attribution: layer.attribution,
    maxZoom: 18,
    subdomains: ['a', 'b', 'c']
  }).addTo(map);
  document.querySelectorAll('.map-controls button').forEach(btn => btn.classList.remove('active'));
  const thisBtn = document.getElementById('map-' + type);
  if(thisBtn) thisBtn.classList.add('active');
}

const tectonicBoundaries = {
  convergent: [
    [[50, -125], [42, -123], [36, -120], [32, -115]],
    [[45, 152], [35, 141], [30, 135], [25, 130]],
    [[0, -78], [-10, -75], [-20, -70], [-30, -72], [-45, -73]],
    [[8, -82], [10, -84], [15, -92]]
  ],
  divergent: [
    [[65, -25], [40, -20], [20, -15], [0, -10], [-20, -5], [-40, 0]],
    [[20, -110], [10, -112], [0, -115], [-10, -118], [-20, -115]]
  ],
  transform: [
    [[42, -123], [38, -121], [36, -120], [32, -115]],
    [[-45, 166], [-42, 170], [-40, 172], [-38, 177]]
  ]
};

function addTectonicOverlays() {
  tectonicOverlays.forEach(overlay => map.removeLayer(overlay));
  tectonicOverlays = [];

  if (document.getElementById('l-convergent').checked) {
    tectonicBoundaries.convergent.forEach(coords => {
      const polyline = L.polyline(coords, {
        color: '#FF3333',
        weight: 3,
        opacity: 0.8
      }).addTo(map);
      tectonicOverlays.push(polyline);
      addSubductionTriangles(coords, polyline);
    });
  }
  
  if (document.getElementById('l-divergent').checked) {
    tectonicBoundaries.divergent.forEach(coords => {
      const polyline = L.polyline(coords, {
        color: '#4CAF50',
        weight: 2,
        opacity: 0.8,
        dashArray: '5, 5'
      }).addTo(map);
      tectonicOverlays.push(polyline);
    });
  }
  
  if (document.getElementById('l-transform').checked) {
    tectonicBoundaries.transform.forEach(coords => {
      const polyline = L.polyline(coords, {
        color: '#FF9800',
        weight: 2,
        opacity: 0.8,
        dashArray: '8, 4'
      }).addTo(map);
      tectonicOverlays.push(polyline);
    });
  }
}

function addSubductionTriangles(coords, polyline) {
  if (coords.length < 2) return;
  const start = coords[coords.length-2];
  const end = coords[coords.length-1];
  const angle = Math.atan2(end[1]-start[1], end[0]-start[0]);
  const offset = 0.8;
  const head = end;
  const left = [end[0] - offset*Math.cos(angle-Math.PI/7), end[1] - offset*Math.sin(angle-Math.PI/7)];
  const right = [end[0] - offset*Math.cos(angle+Math.PI/7), end[1] - offset*Math.sin(angle+Math.PI/7)];
  const triangle = L.polygon([head, left, right], {
    color: '#FF3333',
    fillOpacity:0.65,
    weight: 0
  }).addTo(map);
  tectonicOverlays.push(triangle);
}

function addPlateMotionVectors() {
  const vectors = [
    { lat: 0, lon: -140, speed: 80, direction: 300, name: 'Pacific Plate', color: '#4CAF50' },
    { lat: 45, lon: -100, speed: 20, direction: 245, name: 'N. American Plate', color: '#2196F3' },
    { lat: 55, lon: 90, speed: 25, direction: 95, name: 'Eurasian Plate', color: '#9C27B0' },
    { lat: -25, lon: 135, speed: 70, direction: 35, name: 'Australian Plate', color: '#00BCD4' },
    { lat: -15, lon: -60, speed: 25, direction: 270, name: 'S. American Plate', color: '#E91E63' },
    { lat: -20, lon: -100, speed: 150, direction: 80, name: 'Nazca Plate (fastest!)', color: '#F44336' }
  ];
  vectors.forEach(v => {
    const distance = (v.speed/150)*8;
    const angleRad = (v.direction * Math.PI) / 180;
    const endLat = v.lat + (distance) * Math.sin(angleRad);
    const endLon = v.lon + (distance) * Math.cos(angleRad);
    const arrow = L.polyline(
      [[v.lat, v.lon], [endLat, endLon]],
      {
        color: v.color,
        weight: 3,
        opacity: 0.9
      }
    ).addTo(map);
    const arrowMarker = L.marker([endLat, endLon], {
      icon: L.divIcon({
        className: 'arrow-head',
        html: `<div style="
          width: 0;
          height: 0;
          border-left: 8px solid transparent;
          border-right: 8px solid transparent;
          border-bottom: 15px solid ${v.color};
          transform: rotate(${v.direction}deg);
        "></div>`,
        iconSize: [16,16],
        iconAnchor: [8,8]
      })
    }).addTo(map);
    const label = L.marker([v.lat, v.lon], {
      icon: L.divIcon({
        className: 'plate-label',
        html: `<div style="
          background: rgba(0,0,0,0.7); color: ${v.color}; padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; white-space: nowrap;">
          ${v.name}<br>${v.speed}&nbsp;mm/yr</div>`,
        iconAnchor: [0,30]
      })
    }).addTo(map);
    tectonicOverlays.push(arrow, arrowMarker, label);
  });
}

function addEarthquakeMarkers(earthquakes) {
  earthquakeMarkers.forEach(marker => map.removeLayer(marker));
  earthquakeMarkers = [];
  earthquakes.forEach(eq => {
    const iconSize = Math.max(10, eq.mag * 4);
    let iconColor = '#FFC107';
    if (eq.mag >= 6) iconColor = '#F44336';
    else if (eq.mag >= 5.5) iconColor = '#FF9800';
    const icon = L.divIcon({
      className: 'earthquake-marker',
      html: `<div style="
        width: ${iconSize}px; height: ${iconSize}px;
        background: ${iconColor}; border: 2px solid white;
        border-radius: 50%; box-shadow: 0 0 10px rgba(255,255,255,0.5);"></div>`,
      iconSize: [iconSize, iconSize],
      iconAnchor: [iconSize/2, iconSize/2]
    });
    const marker = L.marker([eq.lat, eq.lon], { icon: icon })
      .bindPopup(`
        <div style="color: #000; font-family: Arial;">
          <h3 style="margin: 0 0 10px 0; color: ${iconColor};">M${eq.mag} Earthquake</h3>
          <p style="margin: 5px 0;"><strong>Location:</strong> ${eq.place}</p>
          <p style="margin: 5px 0;"><strong>Depth:</strong> ${eq.depth} km</p>
          <p style="margin: 5px 0;"><strong>Coordinates:</strong> ${eq.lat.toFixed(2)}°, ${eq.lon.toFixed(2)}°</p>
          <p style="margin: 5px 0;"><strong>Time:</strong> ${eq.time || 'Recent'}</p>
        </div>
      `)
      .addTo(map);
    earthquakeMarkers.push(marker);
  });
  document.getElementById('eq-count').textContent = earthquakes.length;
}

function zoomToRegion(region) {
  const regions = {
    world: { center: [20, 0], zoom: 2 },
    ring: { center: [0, -140], zoom: 3 },
    japan: { center: [37, 137], zoom: 6 },
    cali: { center: [37, -120], zoom: 7 }
  };
  const r = regions[region];
  if(r) map.setView(r.center, r.zoom);
}

function updateMapLayers() {
  addTectonicOverlays();
  if (document.getElementById('l-vectors').checked) {
    addPlateMotionVectors();
  }
  if (document.getElementById('l-earthquakes').checked) {
    earthquakeMarkers.forEach(marker => marker.addTo(map));
  } else {
    earthquakeMarkers.forEach(marker => map.removeLayer(marker));
  }
}

async function fetchRealEarthquakeData() {
  try {
    const response = await fetch('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson');
    const data = await response.json();
    const earthquakes = data.features.map(feature => ({
      mag: feature.properties.mag,
      place: feature.properties.place,
      lat: feature.geometry.coordinates[1],
      lon: feature.geometry.coordinates[0],
      depth: feature.geometry.coordinates[2],
      time: new Date(feature.properties.time).toLocaleString(),
      date: new Date(feature.properties.time)
    }));
    
    // Store for correlation analysis
    historicalEarthquakes = earthquakes;
    
    addEarthquakeMarkers(earthquakes);
    checkEarthquakeAlerts(earthquakes);
    
    document.getElementById('footer-status').textContent = 'Real Data - USGS & NOAA';
    document.getElementById('map-update').textContent = new Date().toLocaleTimeString();
    document.getElementById('data-source').textContent = 'USGS';
  } catch (error) {
    // Add demo earthquakes with dates
    const demoWithDates = demoEarthquakes.map(eq => ({
      ...eq,
      date: new Date(eq.time)
    }));
    historicalEarthquakes = demoWithDates;
    addEarthquakeMarkers(demoEarthquakes);
    document.getElementById('footer-status').textContent = 'Demo Mode';
    document.getElementById('map-update').textContent = 'Demo';
    document.getElementById('data-source').textContent = 'Demo';
  }
}

document.addEventListener('DOMContentLoaded', function() {
  initializeMap();
  fetchRealEarthquakeData();
  addTectonicOverlays();
  addPlateMotionVectors();

  document.querySelectorAll('.map-sidebar input[type="checkbox"]').forEach(checkbox => {
    checkbox.addEventListener('change', updateMapLayers);
  });

  document.getElementById('l-convergent').checked = true;
  document.getElementById('l-divergent').checked = true;
  document.getElementById('l-transform').checked = true;

  setInterval(fetchRealEarthquakeData, 60000);
  
  drawSpaceCharts();
  fetchNOAASpaceWeather();
});

// ===== TAB SWITCHING =====
function switchTab(tabName) {
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });
  
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  
  document.getElementById(tabName + '-tab').classList.add('active');
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
  
  if (tabName === 'map' && map) {
    setTimeout(() => map.invalidateSize(), 100);
  }
}

// ===== NOAA DATA FETCHING =====
async function fetchNOAASpaceWeather() {
  try {
    // Fetch solar wind data
    const swResponse = await fetch(NOAA_APIS.solarWind);
    const swData = await swResponse.json();
    
    if (swData && swData.length > 0) {
      const latest = swData[swData.length - 1];
      spaceWeatherCache.solarWind = {
        speed: parseFloat(latest.speed) || 450,
        density: parseFloat(latest.density) || 5,
        bt: parseFloat(latest.bt) || 5,
        bz: parseFloat(latest.bz_gsm) || 0,
        timestamp: latest.time_tag
      };
    }
    
    // Fetch Kp index
    const kpResponse = await fetch(NOAA_APIS.kpIndex);
    const kpData = await kpResponse.json();
    
    if (kpData && kpData.length > 0) {
      const latestKp = kpData[kpData.length - 1];
      const kpValue = parseFloat(latestKp.kp_index) || parseFloat(latestKp.kp) || 3;
      spaceWeatherCache.kpIndex = {
        value: kpValue,
        status: getKpStatus(kpValue),
        timestamp: latestKp.time_tag
      };
      
      // Store for correlation analysis
      if (kpValue >= 5) {
        historicalStorms.push({
          kp: kpValue,
          date: new Date(latestKp.time_tag),
          timestamp: latestKp.time_tag
        });
        // Keep only last 30 days
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
        historicalStorms = historicalStorms.filter(s => s.date >= thirtyDaysAgo);
      }
    }
    
    // Fetch X-ray flux
    const xrayResponse = await fetch(NOAA_APIS.xrayFlux);
    const xrayData = await xrayResponse.json();
    
    if (xrayData && xrayData.length > 0) {
      const recentFlares = detectFlares(xrayData);
      spaceWeatherCache.xrayFlux = recentFlares;
    }
    
    spaceWeatherCache.lastUpdate = Date.now();
    updateSpaceWeatherDisplay();
    checkSpaceWeatherAlerts();
    
    return true;
  } catch (error) {
    console.log('NOAA API error, using demo data:', error.message);
    // Use demo data
    spaceWeatherCache.solarWind = { speed: 450, density: 5.0, bt: 5, bz: 0, timestamp: new Date().toISOString() };
    spaceWeatherCache.kpIndex = { value: 3, status: 'Quiet', timestamp: new Date().toISOString() };
    spaceWeatherCache.lastUpdate = Date.now();
    updateSpaceWeatherDisplay();
    return false;
  }
}

function getKpStatus(kp) {
  if (kp < 4) return 'Quiet';
  if (kp < 5) return 'Unsettled';
  if (kp < 6) return 'Active';
  if (kp < 7) return 'Minor Storm (G1)';
  if (kp < 8) return 'Moderate Storm (G2)';
  if (kp < 9) return 'Strong Storm (G3)';
  return 'Severe Storm (G4+)';
}

function detectFlares(xrayData) {
  const flares = [];
  const threshold = 1e-6; // C-class threshold
  
  for (let i = 1; i < xrayData.length && i < 500; i++) {
    const current = parseFloat(xrayData[i].flux);
    const previous = parseFloat(xrayData[i-1].flux);
    
    if (current > threshold && current > previous * 2) {
      let flareClass = 'C';
      let flareLevel = (current / 1e-6).toFixed(1);
      if (current > 1e-5) {
        flareClass = 'M';
        flareLevel = (current / 1e-5).toFixed(1);
      }
      if (current > 1e-4) {
        flareClass = 'X';
        flareLevel = (current / 1e-4).toFixed(1);
      }
      
      flares.push({
        class: flareClass,
        level: flareLevel,
        flux: current,
        time: xrayData[i].time_tag
      });
    }
  }
  
  return flares.slice(-10);
}

function updateSpaceWeatherDisplay() {
  const sw = spaceWeatherCache.solarWind;
  const kp = spaceWeatherCache.kpIndex;
  
  if (sw) {
    document.getElementById('solar-wind-speed').textContent = Math.round(sw.speed);
    document.getElementById('solar-wind-density').textContent = sw.density.toFixed(1);
    document.getElementById('solar-wind-bz').textContent = sw.bz.toFixed(1);
  }
  
  if (kp) {
    document.getElementById('kp-value').textContent = kp.value.toFixed(1);
    const statusEl = document.getElementById('kp-status');
    statusEl.textContent = kp.status;
    
    // Color code Kp status
    if (kp.value < 4) statusEl.style.color = '#4CAF50';
    else if (kp.value < 5) statusEl.style.color = '#FFC107';
    else if (kp.value < 7) statusEl.style.color = '#FF9800';
    else statusEl.style.color = '#F44336';
  }
  
  // Update flare info
  const flares = spaceWeatherCache.xrayFlux;
  if (flares && flares.length > 0) {
    document.getElementById('flare-count').textContent = flares.length;
    const latest = flares[flares.length - 1];
    document.getElementById('latest-flare').textContent = `${latest.class}${latest.level}`;
    
    const flareList = document.getElementById('flare-list');
    const flareHTML = flares.slice(-5).reverse().map(f => 
      `<div>${f.class}${f.level} - ${new Date(f.time).toLocaleTimeString()}</div>`
    ).join('');
    flareList.innerHTML = flareHTML || 'No recent flares';
  } else {
    document.getElementById('flare-count').textContent = '0';
    document.getElementById('latest-flare').textContent = 'None';
    document.getElementById('flare-list').textContent = 'No flares detected in last 7 days';
  }
  
  // Update last update time
  const lastUpdate = new Date(spaceWeatherCache.lastUpdate);
  document.getElementById('space-last-update').textContent = lastUpdate.toLocaleTimeString();
}

// ===== NOTIFICATION SYSTEM =====
async function requestNotificationPermission() {
  if (!('Notification' in window)) {
    alert('Your browser does not support notifications');
    return false;
  }
  
  if (Notification.permission === 'granted') {
    document.getElementById('notification-status').textContent = '✓ Enabled';
    return true;
  }
  
  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      document.getElementById('notification-status').textContent = '✓ Enabled';
      showInAppNotification('Notifications Enabled', 'You will receive alerts for major events', 'success');
      return true;
    }
  }
  
  document.getElementById('notification-status').textContent = '✗ Disabled';
  return false;
}

function sendNotification(title, message, icon, url) {
  if (!alertSettings.enabled) return;
  
  if (Notification.permission === 'granted') {
    const notification = new Notification(title, {
      body: message,
      icon: icon || '🌍',
      tag: 'space-earth-monitor',
      requireInteraction: false
    });
    
    notification.onclick = function() {
      window.focus();
      notification.close();
    };
    
    setTimeout(() => notification.close(), 10000);
  }
  
  // Always show in-app notification
  const type = title.includes('Storm') ? 'warning' : title.includes('Earthquake') ? 'error' : 'info';
  showInAppNotification(title, message, type);
}

function showInAppNotification(title, message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <div class="toast-header">
      <strong>${title}</strong>
      <button onclick="this.parentElement.parentElement.remove()">×</button>
    </div>
    <div class="toast-body">${message}</div>
  `;
  
  const container = document.getElementById('toast-container');
  if (container) {
    container.appendChild(toast);
    setTimeout(() => toast.classList.add('show'), 100);
    
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 8000);
  }
}

function checkSpaceWeatherAlerts() {
  const kp = spaceWeatherCache.kpIndex;
  const flares = spaceWeatherCache.xrayFlux;
  
  if (kp && kp.value >= alertSettings.kpThreshold) {
    sendNotification(
      '⚠️ Geomagnetic Storm Alert',
      `Kp index: ${kp.value.toFixed(1)} (${kp.status})`,
      '⚡'
    );
  }
  
  if (flares && flares.length > 0) {
    const flareThreshold = alertSettings.solarFlareClass;
    const recentMajorFlares = flares.filter(f => {
      if (flareThreshold === 'X') return f.class === 'X';
      if (flareThreshold === 'M') return f.class === 'M' || f.class === 'X';
      return true;
    });
    
    if (recentMajorFlares.length > 0) {
      const flare = recentMajorFlares[recentMajorFlares.length - 1];
      const flareTime = new Date(flare.time);
      const timeDiff = Date.now() - flareTime.getTime();
      
      // Only alert if flare is within last 2 hours
      if (timeDiff < 2 * 60 * 60 * 1000) {
        sendNotification(
          `☀️ ${flare.class}${flare.level} Solar Flare Detected`,
          `Detected at ${flareTime.toLocaleTimeString()}`,
          '🌞'
        );
      }
    }
  }
}

function checkEarthquakeAlerts(earthquakes) {
  earthquakes.forEach(eq => {
    if (eq.mag >= alertSettings.earthquakeMagnitude) {
      // Check if we haven't alerted for this one recently
      const alerted = historicalEarthquakes.find(h => 
        h.lat === eq.lat && h.lon === eq.lon && h.mag === eq.mag
      );
      
      if (!alerted) {
        sendNotification(
          `🌍 Major Earthquake M${eq.mag.toFixed(1)}`,
          `${eq.place} - Depth: ${eq.depth}km`,
          '🔴'
        );
      }
    }
  });
}

// ===== CORRELATION TIMELINE =====
function drawCorrelationTimeline() {
  const canvas = document.getElementById('correlation-timeline');
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  
  // Clear canvas
  ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-background');
  ctx.fillRect(0, 0, width, height);
  
  // Timeline axis
  const timelineY = height / 2;
  ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-border');
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(50, timelineY);
  ctx.lineTo(width - 50, timelineY);
  ctx.stroke();
  
  const now = new Date();
  const thirtyDaysAgo = new Date(now - 30 * 24 * 60 * 60 * 1000);
  
  // Get storms and earthquakes
  const storms = getGeomagneticStorms(thirtyDaysAgo, now);
  const earthquakes = getMajorEarthquakes(thirtyDaysAgo, now);
  
  // Plot geomagnetic storms (top)
  ctx.fillStyle = '#FF9800';
  ctx.font = '10px Arial';
  storms.forEach(storm => {
    const x = mapDateToX(storm.date, thirtyDaysAgo, now, 50, width - 50);
    const y = timelineY - 80;
    
    ctx.fillStyle = storm.kp >= 7 ? '#F44336' : '#FF9800';
    ctx.beginPath();
    ctx.arc(x, y, 8, 0, 2 * Math.PI);
    ctx.fill();
    
    ctx.fillStyle = '#FF9800';
    ctx.fillText(`Kp${storm.kp.toFixed(1)}`, x - 15, y - 15);
  });
  
  // Plot earthquakes (bottom)
  earthquakes.forEach(eq => {
    const x = mapDateToX(eq.date, thirtyDaysAgo, now, 50, width - 50);
    const y = timelineY + 80;
    
    ctx.fillStyle = eq.mag >= 6 ? '#F44336' : '#FFC107';
    ctx.beginPath();
    ctx.arc(x, y, 6, 0, 2 * Math.PI);
    ctx.fill();
    
    ctx.fillStyle = '#FFC107';
    ctx.fillText(`M${eq.mag.toFixed(1)}`, x - 12, y + 20);
  });
  
  // Draw correlation lines (27-28 day lag)
  let correlationCount = 0;
  ctx.strokeStyle = 'rgba(76, 175, 80, 0.3)';
  ctx.lineWidth = 1;
  storms.forEach(storm => {
    const stormDate = new Date(storm.date);
    const lagDate = new Date(stormDate.getTime() + 27.5 * 24 * 60 * 60 * 1000);
    
    const correlatedEqs = earthquakes.filter(eq => {
      const diff = Math.abs(eq.date - lagDate) / (24 * 60 * 60 * 1000);
      return diff <= 3;
    });
    
    correlatedEqs.forEach(eq => {
      const x1 = mapDateToX(stormDate, thirtyDaysAgo, now, 50, width - 50);
      const y1 = timelineY - 80;
      const x2 = mapDateToX(eq.date, thirtyDaysAgo, now, 50, width - 50);
      const y2 = timelineY + 80;
      
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      correlationCount++;
    });
  });
  
  // Labels
  ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--color-text-secondary');
  ctx.font = '12px Arial';
  ctx.fillText('Geomagnetic Storms', 60, timelineY - 100);
  ctx.fillText('Major Earthquakes', 60, timelineY + 100);
  
  // Date labels
  ctx.font = '10px Arial';
  const dateLabels = [0, 7, 14, 21, 28];
  dateLabels.forEach(days => {
    const date = new Date(thirtyDaysAgo.getTime() + days * 24 * 60 * 60 * 1000);
    const x = mapDateToX(date, thirtyDaysAgo, now, 50, width - 50);
    const dateStr = `${date.getMonth()+1}/${date.getDate()}`;
    ctx.fillText(dateStr, x - 15, timelineY + 20);
  });
  
  // Update stats
  document.getElementById('storm-count').textContent = storms.length;
  document.getElementById('major-eq-count').textContent = earthquakes.length;
  document.getElementById('correlation-strength').textContent = correlationCount;
}

function mapDateToX(date, startDate, endDate, minX, maxX) {
  const totalTime = endDate - startDate;
  const elapsed = date - startDate;
  return minX + (elapsed / totalTime) * (maxX - minX);
}

function getGeomagneticStorms(startDate, endDate) {
  // Return actual storms from cache + generate some historical demo data
  const storms = historicalStorms.filter(s => s.date >= startDate && s.date <= endDate);
  
  // Add demo storms for visualization
  const demoStorms = [
    { kp: 6.5, date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) },
    { kp: 5.2, date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000) },
    { kp: 7.1, date: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000) }
  ].filter(s => s.date >= startDate && s.date <= endDate);
  
  return [...storms, ...demoStorms];
}

function getMajorEarthquakes(startDate, endDate) {
  return historicalEarthquakes.filter(eq => 
    eq.date >= startDate && eq.date <= endDate && eq.mag >= 5.0
  );
}

function updateCorrelationWindow() {
  const now = new Date();
  const windowStart = new Date(now - 28 * 24 * 60 * 60 * 1000);
  const windowEnd = new Date(now - 27 * 24 * 60 * 60 * 1000);
  
  document.getElementById('window-start').textContent = windowStart.toLocaleDateString();
  document.getElementById('window-end').textContent = windowEnd.toLocaleDateString();
  
  const storms = getGeomagneticStorms(windowStart, windowEnd);
  
  const statusEl = document.getElementById('window-status');
  if (storms.length > 0) {
    statusEl.innerHTML = `⚠️ <strong>Active Correlation Window</strong><br>
      ${storms.length} geomagnetic storm(s) detected 27-28 days ago. 
      Research suggests increased earthquake probability.`;
    statusEl.style.color = '#FF9800';
  } else {
    statusEl.textContent = '✓ No correlation window active';
    statusEl.style.color = '#4CAF50';
  }
}

function refreshCorrelationData() {
  updateCorrelationWindow();
  drawCorrelationTimeline();
  showInAppNotification('Correlation Data Updated', 'Timeline refreshed with latest data', 'info');
}

// ===== SETTINGS FUNCTIONS =====
function toggleAlerts() {
  alertSettings.enabled = document.getElementById('alert-enabled').checked;
  const status = alertSettings.enabled ? 'enabled' : 'disabled';
  showInAppNotification('Alert Settings', `Notifications ${status}`, 'info');
}

function saveAlertSettings() {
  alertSettings.earthquakeMagnitude = parseFloat(document.getElementById('alert-eq-mag').value);
  alertSettings.kpThreshold = parseInt(document.getElementById('alert-kp').value);
  alertSettings.solarFlareClass = document.getElementById('alert-flare').value;
  alertSettings.enabled = document.getElementById('alert-enabled').checked;
  
  showInAppNotification(
    'Settings Saved',
    `EQ: M${alertSettings.earthquakeMagnitude}+, Kp: ${alertSettings.kpThreshold}+, Flare: ${alertSettings.solarFlareClass}+`,
    'success'
  );
}

// ===== DATA REFRESH FUNCTIONS =====
function refreshSpaceData() {
  const speed = Math.floor(Math.random() * 300 + 300);
  const density = Math.floor(Math.random() * 10 + 3);
  const kp = (Math.random() * 6 + 1).toFixed(1);
  const dst = Math.floor(Math.random() * 40 - 30);
  
  document.getElementById('solar-wind-speed').textContent = speed;
  document.getElementById('solar-wind-density').textContent = density;
  document.getElementById('kp-value').textContent = kp;
  document.getElementById('dst-value').textContent = dst;
  
  const kpNum = parseFloat(kp);
  let status = 'Quiet';
  if (kpNum >= 5) status = 'Storm';
  else if (kpNum >= 4) status = 'Active';
  else if (kpNum >= 3) status = 'Unsettled';
  document.getElementById('kp-status').textContent = status;
  
  drawSpaceCharts();
}

function refreshEarthquakeData() {
  fetchRealEarthquakeData();
  showInAppNotification('Earthquake Data Updated', 'Latest seismic data loaded', 'info');
}

function updateLocation() {
  const location = document.getElementById('location-select').value;
  const temps = { 
    'Stara Pazova, Serbia': 22.5,
    'Belgrade, Serbia': 23.1,
    'Tokyo, Japan': 18.4,
    'New York, USA': 15.2
  };
  document.getElementById('temp').textContent = temps[location] || 22.5;
}

function drawSpaceCharts() {
  const canvas1 = document.getElementById('solar-wind-chart');
  if (canvas1) {
    const ctx = canvas1.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas1.width, canvas1.height);
    ctx.strokeStyle = '#32B8C6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 20; i++) {
      const x = (i / 19) * canvas1.width;
      const y = canvas1.height - (Math.random() * 0.5 + 0.3) * canvas1.height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  
  const canvas2 = document.getElementById('kp-chart');
  if (canvas2) {
    const ctx = canvas2.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas2.width, canvas2.height);
    ctx.fillStyle = '#32B8C6';
    for (let i = 0; i < 12; i++) {
      const height = Math.random() * 0.6 * canvas2.height;
      const x = (i / 11) * canvas2.width;
      const y = canvas2.height - height;
      ctx.fillRect(x, y, canvas2.width / 15, height);
    }
  }
  
  const canvas3 = document.getElementById('magnitude-chart');
  if (canvas3) {
    const ctx = canvas3.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas3.width, canvas3.height);
    ctx.fillStyle = '#32B8C6';
    const mags = [15, 8, 3, 1, 1];
    for (let i = 0; i < mags.length; i++) {
      const height = (mags[i] / 20) * canvas3.height;
      const x = (i / 4) * canvas3.width * 0.8 + 20;
      const y = canvas3.height - height;
      ctx.fillRect(x, y, 30, height);
    }
  }
  
  const canvas4 = document.getElementById('aqi-chart');
  if (canvas4) {
    const ctx = canvas4.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas4.width, canvas4.height);
    ctx.strokeStyle = '#32B8C6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 15; i++) {
      const x = (i / 14) * canvas4.width;
      const y = canvas4.height - (Math.random() * 0.4 + 0.4) * canvas4.height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
}

// ===== WINDOW RESIZE HANDLER =====
window.addEventListener('resize', () => {
  if (map && document.getElementById('map-tab').classList.contains('active')) {
    map.invalidateSize();
  }
});
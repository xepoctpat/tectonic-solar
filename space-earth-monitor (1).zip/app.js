// ===== LEAFLET MAP IMPLEMENTATION =====
let map = null;
let earthquakeMarkers = [];
let tectonicOverlays = [];
let currentTileLayer = null;
let demoEarthquakes = [
  { mag: 6.2, lat: 38.0, lon: 140.0, place: 'Japan Region', depth: 45, time: new Date(Date.now() - 7200000).toLocaleString() },
  { mag: 5.8, lat: -15.0, lon: -173.0, place: 'Tonga', depth: 55, time: new Date(Date.now() - 18000000).toLocaleString() },
  { mag: 5.2, lat: -2.5, lon: 118.0, place: 'Indonesia', depth: 90, time: new Date(Date.now() - 28800000).toLocaleString() },
  { mag: 4.8, lat: 36.0, lon: -120.0, place: 'California', depth: 12, time: new Date(Date.now() - 3600000).toLocaleString() },
  { mag: 4.7, lat: 63.0, lon: -152.0, place: 'Alaska', depth: 22, time: new Date(Date.now() - 14400000).toLocaleString() }
];

const tileLayers = {
  standard: {
    url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    name: 'Standard'
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles © Esri',
    name: 'Satellite'
  },
  terrain: {
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attribution: '© <a href="https://opentopomap.org">OpenTopoMap</a> (CC-BY-SA)',
    name: 'Terrain'
  },
  dark: {
    url: 'https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png',
    attribution: '© <a href="https://carto.com/">CARTO</a>',
    name: 'Dark'
  }
};

function initializeMap() {
  map = L.map('map-display', {
    center: [20, 0],
    zoom: 2,
    zoomControl: false,
    minZoom: 2,
    maxZoom: 18
  });
  currentTileLayer = L.tileLayer(tileLayers.satellite.url, {
    attribution: tileLayers.satellite.attribution,
    maxZoom: 18
  }).addTo(map);
  L.control.zoom({ position: 'bottomright' }).addTo(map);
  L.control.scale({ position: 'bottomleft' }).addTo(map);
}

function switchMapType(type) {
  if (currentTileLayer) map.removeLayer(currentTileLayer);
  const layer = tileLayers[type];
  currentTileLayer = L.tileLayer(layer.url, {
    attribution: layer.attribution,
    maxZoom: 18,
    subdomains: ['a', 'b', 'c']
  }).addTo(map);
  document.querySelectorAll('.map-controls button').forEach(btn => btn.classList.remove('active'));
  const thisBtn = document.getElementById('map-' + type);
  if(thisBtn) thisBtn.classList.add('active');
}

const tectonicBoundaries = {
  convergent: [
    [[50, -125], [42, -123], [36, -120], [32, -115]],
    [[45, 152], [35, 141], [30, 135], [25, 130]],
    [[0, -78], [-10, -75], [-20, -70], [-30, -72], [-45, -73]],
    [[8, -82], [10, -84], [15, -92]]
  ],
  divergent: [
    [[65, -25], [40, -20], [20, -15], [0, -10], [-20, -5], [-40, 0]],
    [[20, -110], [10, -112], [0, -115], [-10, -118], [-20, -115]]
  ],
  transform: [
    [[42, -123], [38, -121], [36, -120], [32, -115]],
    [[-45, 166], [-42, 170], [-40, 172], [-38, 177]]
  ]
};

function addTectonicOverlays() {
  tectonicOverlays.forEach(overlay => map.removeLayer(overlay));
  tectonicOverlays = [];

  if (document.getElementById('l-convergent').checked) {
    tectonicBoundaries.convergent.forEach(coords => {
      const polyline = L.polyline(coords, {
        color: '#FF3333',
        weight: 3,
        opacity: 0.8
      }).addTo(map);
      tectonicOverlays.push(polyline);
      addSubductionTriangles(coords, polyline);
    });
  }
  
  if (document.getElementById('l-divergent').checked) {
    tectonicBoundaries.divergent.forEach(coords => {
      const polyline = L.polyline(coords, {
        color: '#4CAF50',
        weight: 2,
        opacity: 0.8,
        dashArray: '5, 5'
      }).addTo(map);
      tectonicOverlays.push(polyline);
    });
  }
  
  if (document.getElementById('l-transform').checked) {
    tectonicBoundaries.transform.forEach(coords => {
      const polyline = L.polyline(coords, {
        color: '#FF9800',
        weight: 2,
        opacity: 0.8,
        dashArray: '8, 4'
      }).addTo(map);
      tectonicOverlays.push(polyline);
    });
  }
}

function addSubductionTriangles(coords, polyline) {
  if (coords.length < 2) return;
  const start = coords[coords.length-2];
  const end = coords[coords.length-1];
  const angle = Math.atan2(end[1]-start[1], end[0]-start[0]);
  const offset = 0.8;
  const head = end;
  const left = [end[0] - offset*Math.cos(angle-Math.PI/7), end[1] - offset*Math.sin(angle-Math.PI/7)];
  const right = [end[0] - offset*Math.cos(angle+Math.PI/7), end[1] - offset*Math.sin(angle+Math.PI/7)];
  const triangle = L.polygon([head, left, right], {
    color: '#FF3333',
    fillOpacity:0.65,
    weight: 0
  }).addTo(map);
  tectonicOverlays.push(triangle);
}

function addPlateMotionVectors() {
  const vectors = [
    { lat: 0, lon: -140, speed: 80, direction: 300, name: 'Pacific Plate', color: '#4CAF50' },
    { lat: 45, lon: -100, speed: 20, direction: 245, name: 'N. American Plate', color: '#2196F3' },
    { lat: 55, lon: 90, speed: 25, direction: 95, name: 'Eurasian Plate', color: '#9C27B0' },
    { lat: -25, lon: 135, speed: 70, direction: 35, name: 'Australian Plate', color: '#00BCD4' },
    { lat: -15, lon: -60, speed: 25, direction: 270, name: 'S. American Plate', color: '#E91E63' },
    { lat: -20, lon: -100, speed: 150, direction: 80, name: 'Nazca Plate (fastest!)', color: '#F44336' }
  ];
  vectors.forEach(v => {
    const distance = (v.speed/150)*8;
    const angleRad = (v.direction * Math.PI) / 180;
    const endLat = v.lat + (distance) * Math.sin(angleRad);
    const endLon = v.lon + (distance) * Math.cos(angleRad);
    const arrow = L.polyline(
      [[v.lat, v.lon], [endLat, endLon]],
      {
        color: v.color,
        weight: 3,
        opacity: 0.9
      }
    ).addTo(map);
    const arrowMarker = L.marker([endLat, endLon], {
      icon: L.divIcon({
        className: 'arrow-head',
        html: `<div style="
          width: 0;
          height: 0;
          border-left: 8px solid transparent;
          border-right: 8px solid transparent;
          border-bottom: 15px solid ${v.color};
          transform: rotate(${v.direction}deg);
        "></div>`,
        iconSize: [16,16],
        iconAnchor: [8,8]
      })
    }).addTo(map);
    const label = L.marker([v.lat, v.lon], {
      icon: L.divIcon({
        className: 'plate-label',
        html: `<div style="
          background: rgba(0,0,0,0.7); color: ${v.color}; padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; white-space: nowrap;">
          ${v.name}<br>${v.speed}&nbsp;mm/yr</div>`,
        iconAnchor: [0,30]
      })
    }).addTo(map);
    tectonicOverlays.push(arrow, arrowMarker, label);
  });
}

function addEarthquakeMarkers(earthquakes) {
  earthquakeMarkers.forEach(marker => map.removeLayer(marker));
  earthquakeMarkers = [];
  earthquakes.forEach(eq => {
    const iconSize = Math.max(10, eq.mag * 4);
    let iconColor = '#FFC107';
    if (eq.mag >= 6) iconColor = '#F44336';
    else if (eq.mag >= 5.5) iconColor = '#FF9800';
    const icon = L.divIcon({
      className: 'earthquake-marker',
      html: `<div style="
        width: ${iconSize}px; height: ${iconSize}px;
        background: ${iconColor}; border: 2px solid white;
        border-radius: 50%; box-shadow: 0 0 10px rgba(255,255,255,0.5);"></div>`,
      iconSize: [iconSize, iconSize],
      iconAnchor: [iconSize/2, iconSize/2]
    });
    const marker = L.marker([eq.lat, eq.lon], { icon: icon })
      .bindPopup(`
        <div style="color: #000; font-family: Arial;">
          <h3 style="margin: 0 0 10px 0; color: ${iconColor};">M${eq.mag} Earthquake</h3>
          <p style="margin: 5px 0;"><strong>Location:</strong> ${eq.place}</p>
          <p style="margin: 5px 0;"><strong>Depth:</strong> ${eq.depth} km</p>
          <p style="margin: 5px 0;"><strong>Coordinates:</strong> ${eq.lat.toFixed(2)}°, ${eq.lon.toFixed(2)}°</p>
          <p style="margin: 5px 0;"><strong>Time:</strong> ${eq.time || 'Recent'}</p>
        </div>
      `)
      .addTo(map);
    earthquakeMarkers.push(marker);
  });
  document.getElementById('eq-count').textContent = earthquakes.length;
}

function zoomToRegion(region) {
  const regions = {
    world: { center: [20, 0], zoom: 2 },
    ring: { center: [0, -140], zoom: 3 },
    japan: { center: [37, 137], zoom: 6 },
    cali: { center: [37, -120], zoom: 7 }
  };
  const r = regions[region];
  if(r) map.setView(r.center, r.zoom);
}

function updateMapLayers() {
  addTectonicOverlays();
  if (document.getElementById('l-vectors').checked) {
    addPlateMotionVectors();
  }
  if (document.getElementById('l-earthquakes').checked) {
    earthquakeMarkers.forEach(marker => marker.addTo(map));
  } else {
    earthquakeMarkers.forEach(marker => map.removeLayer(marker));
  }
}

async function fetchRealEarthquakeData() {
  try {
    const response = await fetch('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson');
    const data = await response.json();
    const earthquakes = data.features.map(feature => ({
      mag: feature.properties.mag,
      place: feature.properties.place,
      lat: feature.geometry.coordinates[1],
      lon: feature.geometry.coordinates[0],
      depth: feature.geometry.coordinates[2],
      time: new Date(feature.properties.time).toLocaleString()
    }));
    addEarthquakeMarkers(earthquakes);
    document.getElementById('footer-status').textContent = 'Real Data - USGS';
    document.getElementById('map-update').textContent = new Date().toLocaleTimeString();
    document.getElementById('data-source').textContent = 'USGS';
  } catch (error) {
    addEarthquakeMarkers(demoEarthquakes);
    document.getElementById('footer-status').textContent = 'Demo Mode';
    document.getElementById('map-update').textContent = 'Demo';
    document.getElementById('data-source').textContent = 'Demo';
  }
}

document.addEventListener('DOMContentLoaded', function() {
  initializeMap();
  fetchRealEarthquakeData();
  addTectonicOverlays();
  addPlateMotionVectors();

  document.querySelectorAll('.map-sidebar input[type="checkbox"]').forEach(checkbox => {
    checkbox.addEventListener('change', updateMapLayers);
  });

  document.getElementById('l-convergent').checked = true;
  document.getElementById('l-divergent').checked = true;
  document.getElementById('l-transform').checked = true;

  setInterval(fetchRealEarthquakeData, 60000);
  
  drawSpaceCharts();
});

// ===== TAB SWITCHING =====
function switchTab(tabName) {
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });
  
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  
  document.getElementById(tabName + '-tab').classList.add('active');
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
  
  if (tabName === 'map' && map) {
    setTimeout(() => map.invalidateSize(), 100);
  }
}

// ===== DATA REFRESH FUNCTIONS =====
function refreshSpaceData() {
  const speed = Math.floor(Math.random() * 300 + 300);
  const density = Math.floor(Math.random() * 10 + 3);
  const kp = (Math.random() * 6 + 1).toFixed(1);
  const dst = Math.floor(Math.random() * 40 - 30);
  
  document.getElementById('solar-wind-speed').textContent = speed;
  document.getElementById('solar-wind-density').textContent = density;
  document.getElementById('kp-value').textContent = kp;
  document.getElementById('dst-value').textContent = dst;
  
  const kpNum = parseFloat(kp);
  let status = 'Quiet';
  if (kpNum >= 5) status = 'Storm';
  else if (kpNum >= 4) status = 'Active';
  else if (kpNum >= 3) status = 'Unsettled';
  document.getElementById('kp-status').textContent = status;
  
  drawSpaceCharts();
}

function refreshEarthquakeData() {
  fetchRealEarthquakeData();
}

function updateLocation() {
  const location = document.getElementById('location-select').value;
  const temps = { 
    'Stara Pazova, Serbia': 22.5,
    'Belgrade, Serbia': 23.1,
    'Tokyo, Japan': 18.4,
    'New York, USA': 15.2
  };
  document.getElementById('temp').textContent = temps[location] || 22.5;
}

function drawSpaceCharts() {
  const canvas1 = document.getElementById('solar-wind-chart');
  if (canvas1) {
    const ctx = canvas1.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas1.width, canvas1.height);
    ctx.strokeStyle = '#32B8C6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 20; i++) {
      const x = (i / 19) * canvas1.width;
      const y = canvas1.height - (Math.random() * 0.5 + 0.3) * canvas1.height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  
  const canvas2 = document.getElementById('kp-chart');
  if (canvas2) {
    const ctx = canvas2.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas2.width, canvas2.height);
    ctx.fillStyle = '#32B8C6';
    for (let i = 0; i < 12; i++) {
      const height = Math.random() * 0.6 * canvas2.height;
      const x = (i / 11) * canvas2.width;
      const y = canvas2.height - height;
      ctx.fillRect(x, y, canvas2.width / 15, height);
    }
  }
  
  const canvas3 = document.getElementById('magnitude-chart');
  if (canvas3) {
    const ctx = canvas3.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas3.width, canvas3.height);
    ctx.fillStyle = '#32B8C6';
    const mags = [15, 8, 3, 1, 1];
    for (let i = 0; i < mags.length; i++) {
      const height = (mags[i] / 20) * canvas3.height;
      const x = (i / 4) * canvas3.width * 0.8 + 20;
      const y = canvas3.height - height;
      ctx.fillRect(x, y, 30, height);
    }
  }
  
  const canvas4 = document.getElementById('aqi-chart');
  if (canvas4) {
    const ctx = canvas4.getContext('2d');
    ctx.fillStyle = 'rgba(33, 128, 141, 0.1)';
    ctx.fillRect(0, 0, canvas4.width, canvas4.height);
    ctx.strokeStyle = '#32B8C6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i < 15; i++) {
      const x = (i / 14) * canvas4.width;
      const y = canvas4.height - (Math.random() * 0.4 + 0.4) * canvas4.height;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
}

// ===== WINDOW RESIZE HANDLER =====
window.addEventListener('resize', () => {
  if (map && document.getElementById('map-tab').classList.contains('active')) {
    map.invalidateSize();
  }
});